import type { Metadata } from "next";
import { Inter, Poppins } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });
const poppins = Poppins({ 
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  variable: "--font-poppins"
});

export const metadata: Metadata = {
  title: "Geprek Mantul - Ayam Geprek yang Bikin Nagih Abis!",
  description: "Ayam geprek terenak se-Indonesia! Dari level 1 sampe level 10, dijamin bikin ketagihan. Pesan sekarang dan rasakan sensasi pedasnya!",
  keywords: "ayam geprek, makanan pedas, delivery, restaurant, indonesian food",
  authors: [{ name: "Geprek Mantul" }],
  openGraph: {
    title: "Geprek Mantul - Ayam Geprek yang Bikin Nagih Abis!",
    description: "Ayam geprek terenak se-Indonesia! Dari level 1 sampe level 10, dijamin bikin ketagihan.",
    type: "website",
    locale: "id_ID",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className={`${inter.className} ${poppins.variable} antialiased bg-white text-gray-900 overflow-x-hidden`}>
        <div className="min-h-screen flex flex-col">
          {children}
        </div>
      </body>
    </html>
  );
}