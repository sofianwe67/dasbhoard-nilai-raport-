"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Clock, Phone, Instagram, Facebook, Twitter } from "lucide-react";

export default function HomePage() {

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-sm shadow-lg sticky top-0 z-50 border-b-2 border-red-500">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-orange-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">GM</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-red-600 font-poppins">Geprek Mantul</h1>
                <p className="text-sm text-gray-600">Ayam Geprek Terenak!</p>
              </div>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#home" className="text-gray-700 hover:text-red-600 font-medium transition-colors">Home</a>
              <a href="#menu" className="text-gray-700 hover:text-red-600 font-medium transition-colors">Menu</a>
              <a href="#about" className="text-gray-700 hover:text-red-600 font-medium transition-colors">About</a>
              <a href="#contact" className="text-gray-700 hover:text-red-600 font-medium transition-colors">Contact</a>
            </nav>
            <Button className="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-2 rounded-full shadow-lg transform hover:scale-105 transition-all">
              Pesan Sekarang
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative py-20 overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge className="bg-red-100 text-red-600 px-4 py-2 text-sm font-semibold">
                  🔥 Viral di TikTok & Instagram!
                </Badge>
                <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight font-poppins">
                  Ayam Geprek yang 
                  <span className="text-red-600 block">Bikin Nagih Abis!</span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Dari level 1 yang ramah anak-anak sampai level 10 yang bikin nangis keenakan! 
                  Dijamin fresh, crispy, dan pedasnya pas di lidah. Udah ribuan orang ketagihan, kapan giliran kamu?
                </p>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white font-semibold px-8 py-4 rounded-full shadow-xl transform hover:scale-105 transition-all">
                  Order Sekarang Juga!
                </Button>
                <Button variant="outline" size="lg" className="border-2 border-red-600 text-red-600 hover:bg-red-600 hover:text-white font-semibold px-8 py-4 rounded-full transition-all">
                  Lihat Menu
                </Button>
              </div>

              <div className="flex items-center space-x-8 pt-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-600">10K+</div>
                  <div className="text-sm text-gray-600">Happy Customers</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-600">4.9</div>
                  <div className="text-sm text-gray-600 flex items-center">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                    Rating
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-600">24/7</div>
                  <div className="text-sm text-gray-600">Delivery</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="relative z-10">
                <img 
                  src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/267239bb-e148-4adb-ac52-50b8ebb81994.png" 
                  alt="Ayam geprek crispy dengan sambal merah pedas dan nasi putih hangat di piring putih"
                  className="w-full h-auto rounded-3xl shadow-2xl transform hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-yellow-400 rounded-full opacity-20 animate-pulse"></div>
              <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-red-400 rounded-full opacity-20 animate-pulse delay-1000"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Menu Preview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4 font-poppins">Menu Andalan Kita</h2>
            <p className="text-xl text-gray-600">Pilih level pedasmu, dari yang santai sampai yang extreme!</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-2 hover:border-red-500">
              <CardContent className="p-6">
                <img 
                  src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/209b9186-0a8c-4355-a940-46f3cef272b3.png" 
                  alt="Geprek Original level 1-3 dengan ayam crispy dan sambal ringan"
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <h3 className="text-xl font-bold text-gray-900 mb-2">Geprek Original</h3>
                <p className="text-gray-600 mb-4">Level 1-3. Perfect buat yang baru mulai suka pedas!</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-red-600">Rp 15.000</span>
                  <Badge className="bg-green-100 text-green-600">Bestseller</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-2 hover:border-red-500">
              <CardContent className="p-6">
                <img 
                  src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/87f23c3c-43ab-439c-8d2f-ac73c2112ecd.png" 
                  alt="Geprek Spicy level 4-7 dengan sambal merah pedas dan keju"
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <h3 className="text-xl font-bold text-gray-900 mb-2">Geprek Spicy</h3>
                <p className="text-gray-600 mb-4">Level 4-7. Udah mulai berasa nih pedasnya!</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-red-600">Rp 18.000</span>
                  <Badge className="bg-orange-100 text-orange-600">Hot</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-2 hover:border-red-500">
              <CardContent className="p-6">
                <img 
                  src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/cec75edb-090e-46d4-a04a-05eb6ed758c2.png" 
                  alt="Geprek Extreme level 8-10 dengan sambal super pedas dan cabe rawit"
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <h3 className="text-xl font-bold text-gray-900 mb-2">Geprek Extreme</h3>
                <p className="text-gray-600 mb-4">Level 8-10. Cuma buat yang berani tantangan!</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-red-600">Rp 22.000</span>
                  <Badge className="bg-red-100 text-red-600">Extreme</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-orange-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">GM</span>
                </div>
                <span className="text-xl font-bold">Geprek Mantul</span>
              </div>
              <p className="text-gray-400">Ayam geprek terenak yang bikin nagih abis! Dari level 1 sampai 10.</p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Kontak</h4>
              <div className="space-y-2 text-gray-400">
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4" />
                  <span>0812-3456-7890</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4" />
                  <span>Jl. Merdeka No. 123, Jakarta</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4" />
                  <span>Buka 24 Jam</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Menu</h4>
              <div className="space-y-2 text-gray-400">
                <div>Geprek Original</div>
                <div>Geprek Spicy</div>
                <div>Geprek Extreme</div>
                <div>Paket Hemat</div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Follow Us</h4>
              <div className="flex space-x-4">
                <Instagram className="w-6 h-6 text-gray-400 hover:text-pink-500 cursor-pointer transition-colors" />
                <Facebook className="w-6 h-6 text-gray-400 hover:text-blue-500 cursor-pointer transition-colors" />
                <Twitter className="w-6 h-6 text-gray-400 hover:text-blue-400 cursor-pointer transition-colors" />
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Geprek Mantul. All rights reserved. Made with ❤️ for pecinta pedas!</p>
          </div>
        </div>
      </footer>
    </div>
  );
}